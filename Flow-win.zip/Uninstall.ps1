﻿# Flow: uninstall. (Saved with a BOM so Windows PowerShell 5.1 reads the Japanese text.)
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms

$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ans = [System.Windows.Forms.MessageBox]::Show(
    "Flow をアンインストールします（設定も消えます）。`nタスクバーの景色を元に戻すため、Explorer を再起動します。`n`nよろしいですか？",
    'Flow', 'OKCancel', 'Question')
if ($ans -ne 'OK') { exit 0 }

# stop what runs from this folder
Get-Process -Name FlowTray, FlowWall, watch | Where-Object { $_.Path -and $_.Path.StartsWith($dir, [StringComparison]::OrdinalIgnoreCase) } |
    Stop-Process -Force
Start-Sleep -Milliseconds 800

# remove the entries
Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'Flow'
$menu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
Remove-Item (Join-Path $menu 'Flow.lnk') -Force
Remove-Item (Join-Path $menu 'Flow - uninstall.lnk') -Force
Remove-Item (Join-Path $menu 'Flow - on.lnk') -Force
Remove-Item (Join-Path $menu 'Flow - off.lnk') -Force

# the layer is loaded inside Explorer: a fresh Explorer unloads it
$loaded = $false
foreach ($p in Get-Process -Name explorer) { foreach ($m in $p.Modules) { if ($m.ModuleName -like 'xamlh*') { $loaded = $true } } }
if ($loaded) { Stop-Process -Name explorer -Force; Start-Sleep -Seconds 3 }

# delete the folder (this script is inside it, so a helper does it after this script ends)
$cmd = 'ping 127.0.0.1 -n 3 >nul & rd /s /q "' + $dir + '"'
Start-Process -FilePath cmd.exe -ArgumentList '/c', $cmd -WindowStyle Hidden
